# ECG Asistent — prototip Android + API AI

Proiect demonstrativ în limba română pentru selectarea unei fotografii EKG din galerie sau capturarea unei imagini cu camera și trimiterea către un server HTTPS de analiză AI.

## Stadiu și limitări

- Acesta este un prototip, nu un dispozitiv medical validat și nu trebuie folosit ca unic mijloc de diagnostic sau triaj.
- Proiectul nu conține un APK compilat. Mediul în care a fost creat nu are Android SDK, Gradle sau instrumentele de build Android instalate, deci nu pot confirma o compilare aici.
- Interpretarea AI a imaginilor ECG poate fi eronată. Nu folosi rezultatul pentru a exclude urgențe și nu întârzia îngrijirea medicală.
- Nu încărca date identificabile ale pacienților. Fotografiile sunt trimise către serverul configurat de utilizator, iar serverul trimite imaginea către furnizorul AI.
- Înainte de utilizare clinică sunt necesare validare clinică, teste, audit de securitate, conformitate GDPR și evaluarea cerințelor de reglementare aplicabile dispozitivelor medicale.

## Structură

- `app/` — proiect Android nativ Kotlin.
- `backend/` — API FastAPI care transmite imaginea către OpenAI Responses API. Cheia API rămâne pe server.

## Configurarea serverului

1. Folosește un server privat și HTTPS. Nu expune public API-ul fără autentificare, limitare de trafic și protecții adecvate.
2. Configurează variabile de mediu pe server:
   - `OPENAI_API_KEY` — cheia API păstrată numai pe server.
   - `APP_ACCESS_TOKEN` — token aleator, lung, pentru accesul aplicației. Dacă este setat, serverul îl verifică în headerul `X-App-Token`.
   - `OPENAI_MODEL` — opțional, implicit `gpt-4.1`; verifică disponibilitatea modelului în contul tău.
3. Instalează dependențele din `backend/requirements.txt` și rulează `uvicorn main:app --host 0.0.0.0 --port 8000` în directorul `backend`, sau construiește imaginea Docker.
4. Pune API-ul în spatele unui proxy HTTPS cu autentificare/rate limiting. Endpointul folosit în aplicație este URL-ul complet, de exemplu `https://api.exemplu.ro/analyze`.
5. În aplicație, introdu URL-ul și tokenul de acces configurat. Nu folosi o cheie OpenAI ca token de aplicație.

## Compilare APK

Deschide directorul proiectului în Android Studio (versiune compatibilă cu Android Gradle Plugin 8.9.2), instalează Android SDK Platform 35 și JDK 17 sau versiunea cerută de plugin, apoi selectează **Build > Build Bundle(s) / APK(s) > Build APK(s)**. APK-ul debug va fi de regulă în `app/build/outputs/apk/debug/app-debug.apk`.

Acest proiect nu include Gradle Wrapper, deoarece wrapper-ul nu era disponibil în mediul de creare. Android Studio poate sincroniza proiectul cu Gradle instalat sau poți adăuga wrapper-ul dintr-o instalare Gradle compatibilă.
