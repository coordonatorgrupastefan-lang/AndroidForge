package ro.ecgassist.app

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var endpoint: EditText
    private lateinit var accessToken: EditText
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var preview: ImageView
    private lateinit var analyze: Button
    private var selectedUri: Uri? = null
    private var cameraUri: Uri? = null

    private val galleryPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) showImage(uri)
    }
    private val cameraCapture = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok && cameraUri != null) showImage(cameraUri!!)
        else setStatus("Fotografia nu a fost salvată.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(10, 53, 64)
        window.navigationBarColor = android.graphics.Color.rgb(10, 53, 64)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
            setBackgroundColor(android.graphics.Color.rgb(246, 249, 250))
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "ECG ASISTENT"
            textSize = 25f; setTextColor(android.graphics.Color.rgb(10, 53, 64)); setTypeface(null, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Analiză asistată AI • EKG cu 12 derivații"
            textSize = 15f; setTextColor(android.graphics.Color.DKGRAY); setPadding(0, dp(5), 0, dp(18))
        })

        val endpointLabel = label("Adresă server de analiză (HTTPS)")
        root.addView(endpointLabel)
        endpoint = EditText(this).apply {
            hint = "https://serverul-tau.ro/analyze"
            textSize = 14f
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
            setText(getPreferences(MODE_PRIVATE).getString("endpoint", ""))
        }
        root.addView(endpoint, matchWrap())
        root.addView(label("Token de acces la server (dacă este configurat)"))
        accessToken = EditText(this).apply {
            hint = "Token furnizat de administratorul serverului"
            textSize = 14f
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
        }
        root.addView(accessToken, matchWrap())
        root.addView(TextView(this).apply {
            text = "Este necesar un server securizat configurat cu acces la un model AI de analiză a imaginilor. Nu introduce aici o cheie API OpenAI; tokenul de mai sus este doar pentru accesul la serverul tău."
            textSize = 12f; setTextColor(android.graphics.Color.DKGRAY); setPadding(0, dp(2), 0, dp(14))
        })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; weightSum = 2f }
        row.addView(button("Alege din galerie") { galleryPicker.launch("image/*") }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(6) })
        row.addView(button("Fă o fotografie") { launchCamera() }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(6) })
        root.addView(row)

        preview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(android.graphics.Color.WHITE)
            contentDescription = "Previzualizare EKG selectat"
        }
        root.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220)).apply { topMargin = dp(14); bottomMargin = dp(12) })

        analyze = button("Analizează EKG-ul") { runAnalysis() }
        analyze.isEnabled = false
        root.addView(analyze, matchWrap(dp(54)))
        status = TextView(this).apply { text = "Selectează o fotografie clară, cu toate cele 12 derivații vizibile."; textSize = 13f; setTextColor(android.graphics.Color.DKGRAY); setPadding(0, dp(12), 0, dp(8)) }
        root.addView(status)
        root.addView(label("RAPORT AI"))
        result = TextView(this).apply {
            text = "Raportul va apărea aici după analiză."
            textSize = 15f; setTextColor(android.graphics.Color.rgb(32, 44, 48)); setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(android.graphics.Color.WHITE)
        }
        root.addView(result, matchWrap())
        root.addView(TextView(this).apply {
            text = "ATENȚIE MEDICALĂ: aplicația este un prototip de suport decizional, nu un dispozitiv medical validat. Verifică independent toate constatările. Nu întârzia tratamentul sau apelarea serviciilor de urgență. Evită încărcarea datelor personale identificabile."
            textSize = 12f; setTextColor(android.graphics.Color.rgb(150, 48, 32)); setPadding(0, dp(16), 0, 0)
        })
        setContentView(scroll)
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text; textSize = 13f; setTextColor(android.graphics.Color.rgb(10, 83, 94)); setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(0, dp(5), 0, dp(3))
    }

    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 14f
        setOnClickListener { action() }
    }

    private fun matchWrap(height: Int = ViewGroup.LayoutParams.WRAP_CONTENT) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun launchCamera() {
        try {
            val file = File(cacheDir, "ecg_${System.currentTimeMillis()}.jpg")
            cameraUri = FileProvider.getUriForFile(this, "ro.ecgassist.app.fileprovider", file)
            cameraCapture.launch(cameraUri!!)
        } catch (e: Exception) { setStatus("Nu am putut deschide camera: ${e.message}") }
    }

    private fun showImage(uri: Uri) {
        try {
            selectedUri = uri
            contentResolver.openInputStream(uri).use { stream -> preview.setImageBitmap(BitmapFactory.decodeStream(stream)) }
            analyze.isEnabled = true
            setStatus("Imagine selectată. Verifică să fie lizibilă și să conțină toate cele 12 derivații.")
            getPreferences(MODE_PRIVATE).edit().putString("endpoint", endpoint.text.toString()).apply()
        } catch (e: Exception) { setStatus("Nu am putut citi imaginea: ${e.message}") }
    }

    private fun runAnalysis() {
        val uri = selectedUri ?: return
        val base = endpoint.text.toString().trim().removeSuffix("/")
        if (!base.startsWith("https://")) { setStatus("Introdu adresa HTTPS a serverului tău de analiză."); return }
        getPreferences(MODE_PRIVATE).edit().putString("endpoint", base).apply()
        analyze.isEnabled = false
        setStatus("Se încarcă imaginea și se solicită analiza AI…")
        result.text = "Analiză în curs…"
        executor.execute {
            try {
                val boundary = "----ECGAsistent${System.currentTimeMillis()}"
                val conn = (URL(base).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 20000; readTimeout = 90000
                    doOutput = true
                    setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                    setRequestProperty("Accept", "application/json")
                    val token = accessToken.text.toString().trim()
                    if (token.isNotEmpty()) setRequestProperty("X-App-Token", token)
                }
                conn.outputStream.use { out ->
                    val mime = contentResolver.getType(uri)?.takeIf { it in setOf("image/jpeg", "image/png", "image/webp") } ?: "image/jpeg"
                    val extension = when (mime) { "image/png" -> "png"; "image/webp" -> "webp"; else -> "jpg" }
                    out.write("--$boundary\r\nContent-Disposition: form-data; name=\"image\"; filename=\"ecg.$extension\"\r\nContent-Type: $mime\r\n\r\n".toByteArray())
                    contentResolver.openInputStream(uri).use { input ->
                        if (input == null) throw IOException("Imaginea nu mai este disponibilă")
                        input.copyTo(out)
                    }
                    out.write("\r\n--$boundary--\r\n".toByteArray())
                }
                val code = conn.responseCode
                val body = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() } ?: "Fără răspuns de la server."
                val parsed = try { JSONObject(body).optString("analysis", body) } catch (_: Exception) { body }
                runOnUiThread {
                    result.text = if (code in 200..299) parsed else "Eroare server ($code):\n$parsed"
                    setStatus(if (code in 200..299) "Analiza a fost returnată de server. Verifică independent rezultatul." else "Analiza nu a reușit. Verifică adresa și serverul.")
                    analyze.isEnabled = true
                }
                conn.disconnect()
            } catch (e: Exception) {
                runOnUiThread {
                    result.text = "Nu s-a putut efectua analiza.\n${e.message ?: "Eroare de rețea"}"
                    setStatus("Verifică conexiunea la internet și serverul de analiză.")
                    analyze.isEnabled = true
                }
            }
        }
    }

    private fun setStatus(message: String) { if (::status.isInitialized) status.text = message }

    companion object { private const val CAMERA_REQUEST = 4902 }
}
