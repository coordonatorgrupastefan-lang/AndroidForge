import base64
import os
from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import JSONResponse
from openai import OpenAI

app = FastAPI(title="ECG Asistent API", version="0.1.0")

SYSTEM_PROMPT = """Ești un asistent de suport pentru revizuirea electrocardiogramei, nu un medic și nu un dispozitiv medical validat. Analizează doar ceea ce se poate observa în imagine. Scrie în limba română, clar și structurat.

Începe cu o secțiune LIMITĂRI ALE IMAGINII: spune dacă imaginea pare să conțină toate cele 12 derivații, dacă traseele și etichetele sunt lizibile și dacă există artefacte, perspectivă, decupare sau rezoluție insuficientă. Dacă imaginea nu este adecvată, declară explicit că interpretarea este limitată și nu inventa valori.

Dacă imaginea permite, oferă o analiză orientativă în această ordine: (1) ritm și frecvență, doar dacă pot fi estimate; (2) ax electric; (3) intervale PR, QRS, QT/QTc numai dacă sunt măsurabile în mod rezonabil din imagine și calibrarea este vizibilă; (4) morfologie P/QRS/ST/T și modificări pe derivații; (5) posibile tulburări de conducere/aritmii; (6) concluzie diferențială cu nivelul de încredere și ce necesită verificare umană. Separă observațiile vizibile de ipoteze. Nu afirma STEMI/NSTEMI, infarct, embolie sau alt diagnostic ca cert doar din fotografie. Nu presupune calibrarea 25 mm/s sau 10 mm/mV dacă nu este vizibilă. Nu inventa măsurători și nu declara că imaginea exclude patologie.

Adaugă la final: «Această analiză AI este orientativă și nu este un diagnostic validat. Confirmă prin evaluare clinică și interpretare de către personal medical calificat. În cazul simptomelor acute sau al suspiciunii de urgență, nu întârzia îngrijirea medicală.» Dacă observi posibile modificări acute, formulează prudent și recomandă evaluare medicală urgentă, fără să pretinzi certitudine."""

@app.get("/health")
def health():
    return {"status": "ok", "service": "ECG Asistent API"}

@app.post("/analyze")
async def analyze(request: Request, image: UploadFile = File(...)):
    expected_token = os.getenv("APP_ACCESS_TOKEN")
    supplied_token = request.headers.get("x-app-token")
    if expected_token and supplied_token != expected_token:
        raise HTTPException(status_code=401, detail="Token de acces invalid.")
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise HTTPException(status_code=503, detail="Serverul nu este configurat cu OPENAI_API_KEY.")
    if image.content_type not in {"image/jpeg", "image/png", "image/webp"}:
        raise HTTPException(status_code=415, detail="Format acceptat: JPEG, PNG sau WEBP.")
    raw = await image.read()
    if not raw:
        raise HTTPException(status_code=400, detail="Fișierul imagine este gol.")
    if len(raw) > 15 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Imaginea depășește limita de 15 MB.")
    mime = image.content_type
    encoded = base64.b64encode(raw).decode("ascii")
    model = os.getenv("OPENAI_MODEL", "gpt-4.1")
    try:
        client = OpenAI(api_key=api_key)
        response = client.responses.create(
            model=model,
            instructions=SYSTEM_PROMPT,
            input=[{
                "role": "user",
                "content": [
                    {"type": "input_text", "text": "Analizează orientativ această fotografie de EKG standard cu 12 derivații. Dacă fotografia nu permite concluzii fiabile, spune clar acest lucru."},
                    {"type": "input_image", "image_url": f"data:{mime};base64,{encoded}"}
                ]
            }]
        )
        return JSONResponse({"analysis": response.output_text, "model": model, "disclaimer": "Suport orientativ; necesită verificare de către personal medical calificat."})
    except Exception as exc:
        # Avoid returning API credentials or internal stack traces to the mobile client.
        raise HTTPException(status_code=502, detail=f"Serviciul AI nu a putut finaliza analiza ({type(exc).__name__}).")
