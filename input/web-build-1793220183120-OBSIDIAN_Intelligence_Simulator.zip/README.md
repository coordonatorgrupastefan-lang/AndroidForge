# OBSIDIAN — Intelligence Simulator

Aplicație Android demonstrativă cu interfață dark, accente neon și panouri inspirate de consolele de analiză. Toate dosarele, alertele și semnalele sunt fictive; aplicația nu se conectează la sisteme externe și nu este afiliată vreunei agenții.

## Configurație
- Gradle wrapper distribution: **8.11.1**
- Android Gradle Plugin: **8.9.1**
- JDK: **17**
- Java source/target compatibility: **17**
- Kotlin JVM target: **17**
- Kotlin plugin/compiler: **2.0.21** (Kotlin nu are o versiune de limbaj „17”; 17 se referă la ținta JVM)
- Android SDK compile/target: 35
- Minimum Android SDK: 26

## Deschidere / build
1. Extrage arhiva ZIP.
2. Deschide folderul `OBSIDIAN_Intelligence_Simulator` în Android Studio sau într-un mediu compatibil AndroidForge.
3. Selectează JDK 17 pentru Gradle.
4. Lasă Gradle să descarce distribuția 8.11.1 și dependențele, cu internet activ.
5. Generează APK-ul din `app`.

## Observație
Arhiva include configurația Gradle wrapper, dar nu include executabilele `gradlew`/`gradlew.bat` și fișierul binar `gradle-wrapper.jar`. Folosește importul proiectului în Android Studio/AndroidForge sau generează wrapper-ul local cu Gradle 8.11.1.
