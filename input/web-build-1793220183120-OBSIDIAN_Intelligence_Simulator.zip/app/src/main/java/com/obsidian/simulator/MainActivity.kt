package com.obsidian.simulator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Void = Color(0xFF080D12)
private val Panel = Color(0xFF101922)
private val Panel2 = Color(0xFF14212B)
private val Neon = Color(0xFF54F2B5)
private val Cyan = Color(0xFF58C7F3)
private val Muted = Color(0xFF8193A2)
private val White = Color(0xFFEAF2F7)
private val Amber = Color(0xFFFFC66D)
private val Red = Color(0xFFFF6B78)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ObsidianApp() }
    }
}

@Composable
fun ObsidianApp() {
    var selected by remember { mutableStateOf("OVERVIEW") }
    var showNotice by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Void, surface = Panel, primary = Neon, secondary = Cyan,
        onBackground = White, onSurface = White
    )) {
        Scaffold(
            containerColor = Void,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0B1218), contentColor = Muted) {
                    val tabs = listOf(
                        Triple("OVERVIEW", "Overview", Icons.Default.Dashboard),
                        Triple("DOSSIERS", "Dosare", Icons.Default.FolderOpen),
                        Triple("SIGNALS", "Semnale", Icons.Default.Radar),
                        Triple("TOOLS", "Instrumente", Icons.Default.Terminal)
                    )
                    tabs.forEach { (key, label, icon) ->
                        NavigationBarItem(
                            selected = selected == key,
                            onClick = { selected = key },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Neon,
                                selectedTextColor = Neon,
                                indicatorColor = Color(0xFF18352F),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item { TopHeader() }
                item {
                    when (selected) {
                        "DOSSIERS" -> DossiersScreen()
                        "SIGNALS" -> SignalsScreen()
                        "TOOLS" -> ToolsScreen(onAction = { showNotice = true })
                        else -> OverviewScreen(onAction = { selected = it })
                    }
                }
                item { FooterMark() }
            }
            if (showNotice) {
                AlertDialog(
                    onDismissRequest = { showNotice = false },
                    containerColor = Panel2,
                    title = { Text("MOD SIMULARE", color = Neon, fontWeight = FontWeight.Black) },
                    text = { Text("Acțiune demonstrativă. Nicio conexiune externă, urmărire sau operațiune reală nu este efectuată.", color = White) },
                    confirmButton = {
                        TextButton(onClick = { showNotice = false }) {
                            Text("AM ÎNȚELES", color = Neon, fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun TopHeader() {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    modifier = Modifier.size(42.dp).clip(RoundedCornerShape(12.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF173E35), Color(0xFF10212A))))
                        .border(1.dp, Neon.copy(alpha = .55f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Visibility, contentDescription = null, tint = Neon, modifier = Modifier.size(24.dp))
                }
                Column {
                    Text("OBSIDIAN", fontSize = 19.sp, fontWeight = FontWeight.Black, letterSpacing = 2.5.sp, color = White)
                    Text("INTELLIGENCE SIMULATOR", fontSize = 9.sp, letterSpacing = 1.8.sp, color = Muted)
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Box(Modifier.size(6.dp).clip(RoundedCornerShape(50)).background(Neon))
                    Text("SYSTEM ONLINE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Neon)
                }
                Text(SimpleDateFormat("dd MMM yyyy", Locale("ro", "RO")).format(Date()).uppercase(), fontSize = 9.sp, color = Muted)
            }
        }
        Box(
            Modifier.fillMaxWidth().height(1.dp)
                .background(Brush.horizontalGradient(listOf(Color.Transparent, Neon.copy(alpha = .65f), Cyan.copy(alpha = .4f), Color.Transparent)))
        )
    }
}

@Composable
fun OverviewScreen(onAction: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF142A32), Color(0xFF101821), Color(0xFF10141B))))
                .border(1.dp, Color(0xFF2C514F), RoundedCornerShape(22.dp))
                .padding(20.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = Neon, modifier = Modifier.size(15.dp))
                    Text("CENTRU DE COMANDĂ • MOD DEMO", color = Neon, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                }
                Text("CONTROL.\nANALIZĂ.\nPRECIZIE.", color = White, fontSize = 31.sp, lineHeight = 34.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                Text("Interfață fictivă de intelligence pentru scenarii și exerciții.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusPill("SECURE SIM", Neon)
                    StatusPill("LOCAL ONLY", Cyan)
                }
            }
        }

        SectionHeading("TABLOU OPERAȚIONAL", "01 / LIVE")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("DOSARE", "08", "+2 azi", Icons.Default.FolderOpen, Neon, Modifier.weight(1f))
            MetricCard("SEMNALE", "24", "4 prioritare", Icons.Default.Radar, Cyan, Modifier.weight(1f))
            MetricCard("ALERTE", "03", "simulare", Icons.Default.NotificationsActive, Amber, Modifier.weight(1f))
        }

        SectionHeading("MODULE RAPIDE", "ACCES")
        ModuleTile("Dosare de caz", "Fișe fictive și cronologie", Icons.Default.FolderCopy, Neon) { onAction("DOSSIERS") }
        ModuleTile("Analiză semnale", "Fluxuri și indicatori simulați", Icons.Default.Radar, Cyan) { onAction("SIGNALS") }
        ModuleTile("Trusă digitală", "Instrumente demonstrative", Icons.Default.Terminal, Amber) { onAction("TOOLS") }

        SectionHeading("JURNAL DE SISTEM", "ULTIMELE EVENIMENTE")
        EventRow("22:41:08", "Sincronizare locală finalizată", "SISTEM", Neon)
        EventRow("22:39:52", "Pachet de date demo încărcat", "DATE", Cyan)
        EventRow("22:36:17", "Protocol de simulare inițializat", "CORE", Amber)
    }
}

@Composable
fun DossiersScreen() {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        ScreenTitle("DOSARE", "ARHIVĂ DE SCENARII")
        Text("Înregistrări fictive pentru exerciții. Identitățile și evenimentele de mai jos sunt inventate.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        DossierCard("OB-2048", "OPERAȚIUNEA NORTHSTAR", "ANALIZĂ ÎN CURS", Neon, "3 indicii • 2 locații fictive")
        DossierCard("OB-1732", "PROTOCOL ECLIPSE", "REVIZUIRE", Amber, "5 indicii • 1 raport")
        DossierCard("OB-0916", "DOSAR MERIDIAN", "ARHIVAT", Muted, "2 indicii • închis")
        SectionHeading("CRONOLOGIE", "OB-2048")
        EventRow("09:14", "Raport inițial introdus în simulare", "LOG", Neon)
        EventRow("09:32", "Legătură ipotetică adăugată", "ANALIZĂ", Cyan)
        EventRow("10:05", "Revizuire manuală necesară", "ATENȚIE", Amber)
    }
}

@Composable
fun SignalsScreen() {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        ScreenTitle("ANALIZĂ SEMNALE", "PANOU TELEMETRIE DEMO")
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Panel)
                .border(1.dp, Color(0xFF29404B), RoundedCornerShape(20.dp)).padding(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("SPECTRUM / 04", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    StatusPill("FICTIV", Neon)
                }
                Row(
                    Modifier.fillMaxWidth().height(100.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    val bars = listOf(28, 43, 35, 65, 48, 82, 56, 37, 70, 91, 61, 44, 76, 53, 32, 68, 84, 47, 59, 35, 72, 50, 88, 41)
                    bars.forEachIndexed { i, h ->
                        Box(
                            Modifier.weight(1f).fillMaxHeight(h / 100f).clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                                .background(if (i in listOf(5, 9, 16, 22)) Neon else Cyan.copy(alpha = .45f))
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("00:00", color = Muted, fontSize = 9.sp)
                    Text("SIMULATED DATA STREAM", color = Muted, fontSize = 9.sp)
                    Text("23:59", color = Muted, fontSize = 9.sp)
                }
            }
        }
        SectionHeading("INDICATORI", "STATUS")
        SignalRow("Canal Alpha", "Stabil", 0.82f, Neon)
        SignalRow("Canal Bravo", "Variație", 0.54f, Amber)
        SignalRow("Canal Charlie", "Inactiv", 0.18f, Red)
        SectionHeading("ALERTE SIMULATE", "3")
        EventRow("HIGH", "Vârf de activitate detectat", "DEMO", Amber)
        EventRow("MED", "Variație de frecvență", "DEMO", Cyan)
        EventRow("LOW", "Pachet incomplet", "DEMO", Muted)
    }
}

@Composable
fun ToolsScreen(onAction: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        ScreenTitle("TRUSĂ DIGITALĂ", "UTILITARE DEMONSTRATIVE")
        Text("Aceste instrumente nu se conectează la rețele și nu accesează dispozitive externe.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        ToolCard("Cifrul de antrenament", "Exemplu de codificare pentru texte fictive", Icons.Default.Key, Neon, onAction)
        ToolCard("Analizor de metadate", "Vizualizare locală a unui set de date demo", Icons.Default.DataObject, Cyan, onAction)
        ToolCard("Generator de raport", "Inițializează un raport demonstrativ", Icons.Default.Description, Amber, onAction)
        ToolCard("Protocol de verificare", "Listă de verificare pentru exerciții", Icons.Default.FactCheck, Red, onAction)
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF1A211F)).border(1.dp, Color(0xFF5D5035), RoundedCornerShape(14.dp)).padding(14.dp)) {
            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Default.Info, contentDescription = null, tint = Amber)
                Column {
                    Text("MEDIU IZOLAT", color = Amber, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Aplicația este un simulator vizual. Nu reprezintă un produs oficial al vreunei agenții și nu efectuează supraveghere reală.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }
    }
}

@Composable
fun ScreenTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, color = White, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 1.1.sp)
        Text(subtitle, color = Neon, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
    }
}

@Composable
fun SectionHeading(title: String, tag: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
        Text(title, color = White, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
        Text(tag, color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
    }
}

@Composable
fun MetricCard(label: String, value: String, note: String, icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Color, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(Panel).border(1.dp, Color(0xFF263640), RoundedCornerShape(16.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(18.dp))
        Text(value, color = White, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Text(label, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = .6.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(note, color = accent, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun StatusPill(text: String, accent: Color) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(accent.copy(alpha = .10f)).border(1.dp, accent.copy(alpha = .45f), RoundedCornerShape(50)).padding(horizontal = 9.dp, vertical = 5.dp)) {
        Text(text, color = accent, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = .6.sp)
    }
}

@Composable
fun ModuleTile(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel)
            .border(1.dp, Color(0xFF263640), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(15.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(accent.copy(alpha = .10f)), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(23.dp))
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(description, color = Muted, fontSize = 11.sp)
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = accent)
    }
}

@Composable
fun DossierCard(id: String, title: String, status: String, accent: Color, details: String) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).border(1.dp, Color(0xFF263640), RoundedCornerShape(16.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text(id, color = accent, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
            StatusPill(status, accent)
        }
        Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Text(details, color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun EventRow(time: String, title: String, category: String, accent: Color) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Panel).padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.width(3.dp).height(34.dp).clip(RoundedCornerShape(4.dp)).background(accent))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            Text(time, color = Muted, fontSize = 9.sp)
        }
        Text(category, color = accent, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = .5.sp)
    }
}

@Composable
fun SignalRow(title: String, status: String, level: Float, accent: Color) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Panel).padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text(title, color = White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(status, color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(50)).background(Color(0xFF263640))) {
            Box(Modifier.fillMaxWidth(level).fillMaxHeight().clip(RoundedCornerShape(50)).background(accent))
        }
    }
}

@Composable
fun ToolCard(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Color, onAction: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).border(1.dp, Color(0xFF263640), RoundedCornerShape(16.dp)).clickable { onAction() }.padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(24.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(description, color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
        }
        Icon(Icons.Default.ArrowOutward, contentDescription = null, tint = Muted, modifier = Modifier.size(17.dp))
    }
}

@Composable
fun FooterMark() {
    Column(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.width(55.dp).height(1.dp).background(Neon.copy(alpha = .55f)))
        Text("OBSIDIAN // SIMULATOR BUILD 1.0", color = Muted, fontSize = 8.sp, letterSpacing = 1.3.sp)
        Text("FICȚIUNE • LOCAL • FĂRĂ CONEXIUNI EXTERNE", color = Color(0xFF526572), fontSize = 8.sp, letterSpacing = .7.sp)
    }
}
